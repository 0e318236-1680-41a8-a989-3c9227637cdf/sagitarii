#!/bin/bash
java -jar teapot-1.0.125.jar

